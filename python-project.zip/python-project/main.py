print("====================================")
print("       ACT PYTHON LEARNING SYSTEM")
print("====================================")

name = input("Enter Student Name: ")

print("\nWelcome", name, "!")

while True:

    print("\n========== MAIN MENU ==========")
    print("1. PRELIM")
    print("2. MIDTERM")
    print("3. FINALS")
    print("4. EXIT")

    choice = input("\nChoose your period: ")

    # PRELIM
    if choice == "1":

        print("\n========== PRELIM LESSONS ==========")
        print("1. Introduction to Python")
        print("2. Variables")
        print("3. Data Types")
        print("4. Input and Output")
        print("5. Operators")

        lesson = input("Choose lesson: ")

        if lesson == "1":
            print("\nLESSON 1: INTRODUCTION TO PYTHON")
            print("Python is a programming language.")
            print("It is used to create programs and applications.")
            print("Python is easy to read and understand.")
            print("\nExample:")
            print("print('Hello World')")

            print("\nACTIVITY:")
            answer = input("What programming language are we studying? ")
            if answer.lower() == "python":
                print("Correct! Good job!")
            else:
                print("The answer is Python.")

        elif lesson == "2":
            print("\nLESSON 2: VARIABLES")
            print("Variables are used to store information.")
            print("Example:")
            print("name = 'Juan'")
            print("age = 18")
            print("The name variable stores Juan.")
            print("The age variable stores 18.")

            print("\nACTIVITY:")
            student = input("Enter your name: ")
            print("Your name is:", student)

        elif lesson == "3":
            print("\nLESSON 3: DATA TYPES")
            print("String - Text")
            print("Integer - Whole numbers")
            print("Float - Decimal numbers")
            print("Boolean - True or False")
            print("\nExample:")
            print("name = 'Ana'")
            print("age = 18")
            print("grade = 95.5")
            print("passed = True")

            print("\nACTIVITY:")
            number = int(input("Enter a whole number: "))
            print("Your number is:", number)

        elif lesson == "4":
            print("\nLESSON 4: INPUT AND OUTPUT")
            print("Input receives information from the user.")
            print("Print displays information on the screen.")
            print("\nExample:")
            print("name = input('Enter name: ')")
            print("print('Hello', name)")

            print("\nACTIVITY:")
            student = input("Enter your name: ")
            print("Hello", student)

        elif lesson == "5":
            print("\nLESSON 5: OPERATORS")
            print("Operators are used for calculations.")
            print("Addition (+)")
            print("Subtraction (-)")
            print("Multiplication (*)")
            print("Division (/)")

            a = 10
            b = 5

            print("\nExample:")
            print("10 + 5 =", a + b)
            print("10 - 5 =", a - b)
            print("10 * 5 =", a * b)
            print("10 / 5 =", a / b)

        else:
            print("Invalid lesson!")

    # MIDTERM
    elif choice == "2":

        print("\n========== MIDTERM LESSONS ==========")
        print("1. Conditional Statements")
        print("2. If and Else")
        print("3. If Elif Else")
        print("4. While Loop")

        lesson = input("Choose lesson: ")

        if lesson == "1":
            print("\nLESSON 1: CONDITIONAL STATEMENTS")
            print("Conditional statements are used to make decisions.")
            print("They check if a condition is true or false.")
            print("\nExample:")
            print("age = 18")
            print("if age >= 18:")
            print("    print('Adult')")

            age = int(input("\nEnter your age: "))
            if age >= 18:
                print("You are an adult.")
            else:
                print("You are a minor.")

        elif lesson == "2":
            print("\nLESSON 2: IF AND ELSE")
            print("If checks a condition.")
            print("Else runs when the condition is false.")
            print("\nExample:")
            print("grade = 80")
            print("if grade >= 75:")
            print("    print('Passed')")
            print("else:")
            print("    print('Failed')")

            grade = int(input("\nEnter your grade: "))
            if grade >= 75:
                print("Passed!")
            else:
                print("Failed!")

        elif lesson == "3":
            print("\nLESSON 3: IF ELIF ELSE")
            print("Elif means else if.")
            print("It checks another condition.")
            print("\nExample:")
            print("grade = 90")
            print("if grade >= 90:")
            print("    print('Excellent')")
          
